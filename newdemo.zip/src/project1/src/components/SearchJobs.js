import React from 'react';
import {Link} from 'react-router-dom';
import { IMAGES } from '../constants/theme';

const SearchJobs = (props) => {
    return (
        <div className="dz-bnr-inr dz-bnr-inr-sm text-center overlay-primary-dark" style={{backgroundImage: "url("+ IMAGES.Banner +")"}}>
            <div className="container">
                <div className="dz-bnr-inr-entry">
                    <h1 className="wow fadeInUp" id="text" data-wow-delay="0.6s">Find Your Aspiring Job with Endless Opportunities in various industry verticals.</h1>
                    <p className=" text text-primary wow fadeInUp font-w500" data-wow-delay="0.8s">Gateway to your career success.</p>
                    <div className="bnr-search-bar wow fadeInUp" data-wow-delay="1.0s">	
                        <div className="row align-items-center justify-content-center">
                            <div className="col-xl-9 col-lg-8 col-md-9 col-sm-12">
                                <div className="row center-line">
                                    <div className="col-lg-6 col-md-6 col-sm-6 ">
                                        <div className="search-bar">	
                                            <span>
                                                <i className="fa-solid fa-magnifying-glass"></i>
                                            </span>
                                            <div className="icon-content w-100">
                                                <input name="dzEmail" required="required" className="form-control" placeholder="Job Title, Keywords..." type="text" />
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-lg-6 col-md-6 col-sm-6">
                                        <div className="search-bar">	
                                            <span>
                                                <i className="fa-solid fa-location-dot"></i>
                                            </span>
                                            <div className="icon-content w-100">
                                                <input name="dzEmail" required="required" className="form-control" placeholder="City Or Postcode" type="text" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="col-xl-3 col-lg-4 col-md-3 col-sm-12  text-lg-end text-md-center text-center">
                                <Link to={"#"} className="btn btn-primary w-100">Find Jobs</Link>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    );
};

export default SearchJobs;