import React from "react";
import PageTitle from "../components/PageTitle";
import JobsPost from "../elements/JobsPost";
import BlogSideBar from "../elements/JobSideBar";

const JobsGrid = () => {
  return (
    <div className="page-content">
      <PageTitle mainPage="Jobs" activePage="Jobs Grid" />
      <section className="content-inner overflow-hidden position-relative">
        <div className="container">
          <div className="row">
            <div className="col-xl-4 col-lg-4">
              <BlogSideBar />
            </div>
            <div className="col-xl-8 col-lg-8">
              <JobsPost />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default JobsGrid;
