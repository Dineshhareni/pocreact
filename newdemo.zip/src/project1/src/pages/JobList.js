import React from 'react';
import {Link} from 'react-router-dom';

import PageTitle from '../components/PageTitle';
import JobSideBar from '../elements/JobSideBar';
import { IMAGES } from '../constants/theme';
import JobsPost from '../elements/JobsPost';
import SearchJobs from '../components/SearchJobs';

const gridData = [
    {image: IMAGES.BlogPic1, title:'How to convince recruiters and get your dream', date:'14 Feb 2022' },
    {image: IMAGES.BlogPic2, title:'5 things to know about the March 2022', date:'23 June 2022' },
    {image: IMAGES.BlogPic3, title:'Job Board is the most important sector', date:'30 Dec 2022' },
    {image: IMAGES.BlogPic5, title:'These Bizarre Truths Behind Job.', date:'10 Jan 2023' },
];
const BlogList = () => {
    return (
        <div className="page-content">
            <SearchJobs mainPage="Home" activePage="Blog List Sidebar" />
           
            <section className="content-inner bg-white position-relative">
                <div className="container">
                    <div className="row ">
                        <div className="col-xl-4 col-lg-4">
                            <JobSideBar />
                        </div>
                        <div className="col-xl-8 col-lg-8 job-list">
                            <div className="row">
                                <JobsPost />
                                <div className="col-xl-12 col-lg-12 m-b30 m-t30 m-lg-t10">
                                    <nav aria-label="Blog Pagination">
                                        <ul className="pagination style-2 text-center wow fadeInUp" data-wow-delay="0.8s">
                                            <li className="page-item"><Link to={"#"} className="page-link prev"><i className="fas fa-chevron-left"></i></Link></li>
                                            <li className="page-item"><Link to={"#"} className="page-link active">1</Link></li>
                                            <li className="page-item"><Link to={"#"} className="page-link">2</Link></li>
                                            <li className="page-item"><Link to={"#"} className="page-link">3</Link></li>
                                            <li className="page-item"><Link to={"#"} className="page-link next"><i className="fas fa-chevron-right"></i></Link></li>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </section>
        </div>
    );
};

export default BlogList;