import React from "react";
import { Link } from "react-router-dom";
import { IMAGES } from "../constants/theme";

const jobPostBlog = [
  // Added job from image
  {
    image: IMAGES.CompanyPic1,
    title: "IT Administrator",
    amount: "Negotiable",
    company: "Lumiverse Solutions Pvt. Ltd",
    jobRole: "IT Administrator",
    website: "https://www.lumiversesolutions.com/",
    education: "Any Graduation",
    experience: "1 - 2 Years",
    noOfVacancies: 0,
    jobId: "GTPJ63981212",
    specialization: "IT Administrator",
    primarySkills: [
      "Windows Server Administration",
      "Linux systems",
      "Networking",
      "Cloud services",
      "Network Firewalls",
      "Firewalls",
      "Antivirus",
    ],
    jobType: "Permanent",
    industryType: "Information Technology",
    degree: "Any Degree",
    noticePeriod: "Immediate",
    yearlySalary: "INR - Lakhs",
    jobState: "Maharashtra",
    jobCity: "Nashik",
  },
  {
    image: IMAGES.CompanyPic1,
    title: "Need Senior Stock Technician",
    amount: "3500",
  },
  {
    image: IMAGES.CompanyPic2,
    title: "Senior Web Designer , Developer",
    amount: "3000",
  },
  { image: IMAGES.CompanyPic3, title: "IT Department Manager", amount: "3250" },
  {
    image: IMAGES.CompanyPic4,
    title: "Recreation & Fitness Worker",
    amount: "4100",
  },
  {
    image: IMAGES.CompanyPic5,
    title: "Senior Stock Technician",
    amount: "2900",
  },
  {
    image: IMAGES.CompanyPic6,
    title: "Need Senior Stock Technician",
    amount: "2000",
  },
];

const JobsPost = () => {
  return (
    <>
        {jobPostBlog.map((item, index) => (
          <div className="col-xl-12 col-md-12" key={index}>
            <div className="job-bx style-1 wow fadeInUp" data-wow-delay="0.3s">
              

              <div className="d-flex m-b25 justify-content-between">
                <div>
                    <h4>IT Administrator</h4>
                    <h5>Lumiverse Solutions pvt.ltd</h5>
                </div>
                  
                <span className="media">
                  <img src={item.image} alt="post" />
                </span>
               
              </div>


              {/* Two-Column Layout Inside the Card */}
              <div className="row">
                {/* Left Column */}
                <div className="col-md-6">
                  <p>
                    <strong>Job Role:</strong> {item.jobRole || item.title}
                  </p>
                 
                  {item.website && (
                    <p>
                      <strong>Website:</strong>{" "}
                      <a href={item.website} target="_blank" rel="noreferrer">
                        {item.website}
                      </a>
                    </p>
                  )}
                  {item.education && (
                    <p>
                      <strong>Education:</strong> {item.education}
                    </p>
                  )}
                  {item.experience && (
                    <p>
                      <strong>Experience:</strong> {item.experience}
                    </p>
                  )}
                 
                </div>

                {/* Right Column */}
                <div className="col-md-6">
                  {item.jobType && (
                    <p>
                      <strong>Job Type:</strong> {item.jobType}
                    </p>
                  )}
                  {item.industryType && (
                    <p>
                      <strong>Industry:</strong> {item.industryType}
                    </p>
                  )}
                  {item.noticePeriod && (
                    <p>
                      <strong>Acceptable Notice Period:</strong>{" "}
                      {item.noticePeriod}
                    </p>
                  )}
                  {item.yearlySalary && (
                    <p>
                      <strong>Yearly Salary:</strong> {item.yearlySalary}
                    </p>
                  )}
                  {item.jobCity && item.jobState && (
                    <p>
                      <strong>Location:</strong> {item.jobCity}, {item.jobState}
                    </p>
                  )}
                  {item.jobId && (
                    <p>
                      <strong>Job ID:</strong> {item.jobId}
                    </p>
                  )}
                 
                </div>
                <div className="col-md-12">
                    {item.specialization && (
                    <p>
                      <strong>Specialization:</strong> {item.specialization}
                    </p>
                  )}

                   {item.primarySkills && (
                    <p>
                      <strong>Primary Skills:</strong>{" "}
                      {item.primarySkills.join(", ")}
                    </p>
                  )}

                </div>

              </div>

              {/* Bottom Amount & Button */}
              <div className="jobs-amount d-flex justify-content-between align-items-center mt-3">
                <h6 className="amount">
                  ${item.amount}
                  <span>/ month</span>
                </h6>
                <Link to="/job-detail" className="btn btn-primary">
                  <i className="fa-solid fa-chevron-right"></i>
                </Link>
              </div>
            </div>
          </div>
        ))}
    </>
  );
};

export default JobsPost;
