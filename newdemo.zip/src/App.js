import React ,{Fragment} from 'react';
import {BrowserRouter, Routes, Route, Outlet} from 'react-router-dom';

import "./project1/src/assets/vendor/switcher/switcher.css";
import './project1/src/assets/css/style.css'; 
// import './assets/css/skin/skin-1.css';

//Layout 
import Header from './project1/src/components/Header';
import Footer from './project1/src/components/Footer';
//pages
import Home from './project1/src/pages/Home';
import AboutUs from './project1/src/pages/AboutUs';
import JobsGrid from './project1/src/pages/JobsGrid';
import JobDetails from './project1/src/pages/JobDetails';
import Pricing from './project1/src/pages/Pricing';
import BlogGrid from './project1/src/pages/BlogGrid';
import JobList from './project1/src/pages/JobList';
import BlogDetails from './project1/src/pages/BlogDetails';
import ContactUs from './project1/src/pages/ContactUs';
import ScrollToTop from './project1/src/components/ScrollToTop';
import Switcher from './project1/src/components/Switcher';
import AnimatedCursor from './project1/src/components/AnimatedCursor';
import HomePage from './homepage';
let basename = "frontend/react";
function App() {
    return (
      <Fragment>
        <BrowserRouter >
          <Routes >			
			<Route path="/" element = {<Home />} />
			<Route element= {<Layouts/>} >
				<Route path="/about-us" element = {<AboutUs />} />
				<Route path="/jobs-grid" element = {<JobsGrid />} />
				<Route path="/job-detail" element = {<JobDetails />} />
				<Route path="/pricing" element = {<Pricing />} />
				<Route path="/blog-grid" element = {<BlogGrid />} />
				<Route path="/jobs" element = {<JobList />} />
				<Route path="/blog-details" element = {<BlogDetails />} />
				<Route path="/contact-us" element = {<ContactUs />} />
			</Route>	
          </Routes>
		  <AnimatedCursor />
		  <Switcher />
		  <ScrollToTop />
        </BrowserRouter>
      </Fragment>
    );
}

function Layouts(){
	return(
		<>
			<div className='page-wraper'>
				<Header/>
				<Outlet />
				<Footer />
			</div>			
		</>
	)
}

export default App;
