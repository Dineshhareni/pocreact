import React from "react";


const HomePage = () => {
    
    return (
        <p>This is home page -created by dinesh</p>
    )
}

export default HomePage;